/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Cart from './pages/Cart';
import Compare from './pages/Compare';
import Dashboard from './pages/Dashboard';
import Landing from './pages/Landing';
import ManufacturerAnalytics from './pages/ManufacturerAnalytics';
import ManufacturerCatalog from './pages/ManufacturerCatalog';
import Manufacturers from './pages/Manufacturers';
import Orders from './pages/Orders';
import ProductDetail from './pages/ProductDetail';
import Projects from './pages/Projects';
import RetailerAnalytics from './pages/RetailerAnalytics';
import Search from './pages/Search';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Cart": Cart,
    "Compare": Compare,
    "Dashboard": Dashboard,
    "Landing": Landing,
    "ManufacturerAnalytics": ManufacturerAnalytics,
    "ManufacturerCatalog": ManufacturerCatalog,
    "Manufacturers": Manufacturers,
    "Orders": Orders,
    "ProductDetail": ProductDetail,
    "Projects": Projects,
    "RetailerAnalytics": RetailerAnalytics,
    "Search": Search,
}

export const pagesConfig = {
    mainPage: "Landing",
    Pages: PAGES,
    Layout: __Layout,
};
