import { useEffect, useRef, useState } from "react";
import {
  Search,
  ExternalLink,
  X,
  ImageOff,
  Loader2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Heart,
  Share2,
  BookmarkPlus,
  GitCompare,
  History,
  Wand2,
  Radar,
  ShieldCheck,
  Layers3,
  Compass,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import CompareDrawer from "@/components/CompareDrawer";
import { useToast } from "@/components/ui/use-toast";
import { searchProducts } from "@/api/searchClient";
import {
  clearCompareItems,
  getCompareItems,
  getFavorites,
  getRecentSearches,
  getSavedSearches,
  normalizeSearchResult,
  pushRecentSearch,
  removeCompareItem,
  removeSavedSearch,
  saveSearch,
  toggleCompareItem,
  toggleFavorite,
} from "@/lib/growth-store";
import { buildSearchInsights } from "@/lib/ai-assist";

const EXAMPLE_SEARCHES = [
  "comfy modern swivel chair, sustainable materials, under $2k",
  "blue velvet sectional, luxury brand, large living room",
  "sustainable wooden dining chairs, modern style, under $800 each",
  "ergonomic office chair for bad back, dark colors, under $1500",
  "mid-century modern credenza, walnut wood",
  "boucle accent chair, cozy, light neutral colors",
];

function getInitialQuery() {
  const params = new URLSearchParams(window.location.search);
  return params.get("q") || "";
}

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [results, setResults] = useState([]);
  const [intent, setIntent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState("");
  const [error, setError] = useState(null);
  const [searched, setSearched] = useState(false);
  const [sortBy, setSortBy] = useState("relevance");
  const [diagnostics, setDiagnostics] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [savedSearches, setSavedSearches] = useState([]);
  const [recentSearches, setRecentSearches] = useState([]);
  const [compareItems, setCompareItems] = useState([]);
  const inputRef = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    setFavorites(getFavorites());
    setSavedSearches(getSavedSearches());
    setRecentSearches(getRecentSearches());
    setCompareItems(getCompareItems());

    const initialQuery = getInitialQuery();
    if (initialQuery) {
      setInputValue(initialQuery);
      runSearch(initialQuery, { syncUrl: false });
    }
  }, []);

  const runSearch = async (q, { syncUrl = true } = {}) => {
    if (!q.trim()) return;
    const trimmed = q.trim();
    setQuery(trimmed);
    setInputValue(trimmed);
    setLoading(true);
    setError(null);
    setSearched(true);
    setResults([]);
    setIntent(null);
    setDiagnostics(null);

    if (syncUrl) {
      window.history.replaceState({}, "", `/Search?q=${encodeURIComponent(trimmed)}`);
    }

    try {
      setLoadingStage("Understanding your sourcing intent...");
      await new Promise((resolve) => setTimeout(resolve, 350));
      setLoadingStage("Scanning manufacturer domains...");
      await new Promise((resolve) => setTimeout(resolve, 350));
      setLoadingStage("Enriching and ranking product matches...");

      const data = await searchProducts(trimmed);

      setIntent(data.intent || null);
      setResults(data.products || []);
      setDiagnostics(data.diagnostics || null);
      setRecentSearches(pushRecentSearch(trimmed));
    } catch (err) {
      setError("Search failed. Please try again.");
    } finally {
      setLoading(false);
      setLoadingStage("");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    runSearch(inputValue);
  };

  const handleSaveSearch = () => {
    if (!query) return;
    setSavedSearches(saveSearch(query, { resultCount: results.length, summary: intent?.summary || null }));
    toast({ title: "Search saved", description: "You can rerun it from your workspace panel." });
  };

  const handleCopySearchLink = async () => {
    if (!query) return;
    await navigator.clipboard.writeText(`${window.location.origin}/Search?q=${encodeURIComponent(query)}`);
    toast({ title: "Link copied", description: "Share this search with your team or client." });
  };

  const handleToggleFavorite = (item) => {
    const { next, added } = toggleFavorite(normalizeSearchResult(item));
    setFavorites(next);
    toast({ title: added ? "Saved to favorites" : "Removed from favorites", description: item.product_name });
  };

  const handleToggleCompare = (item) => {
    const { next, added, limitReached } = toggleCompareItem(normalizeSearchResult(item));
    setCompareItems(next);
    toast({
      title: limitReached ? "Compare limit reached" : added ? "Added to compare" : "Removed from compare",
      description: limitReached ? "Remove an item before adding another." : item.product_name,
    });
  };

  const sortedResults = [...results].sort((a, b) => {
    if (sortBy === "relevance") return (b.relevance_score || 0) - (a.relevance_score || 0);
    return 0;
  });
  const searchInsights = buildSearchInsights(intent, sortedResults, diagnostics);
  const verifiedResults = sortedResults.filter((item) => item.result_quality === "verified");
  const directionalResults = sortedResults.filter((item) => item.result_quality !== "verified");

  return (
    <div className="relative py-8 md:py-10">
      <div className="page-wrap">
        <section className="surface-panel relative overflow-hidden p-6 md:p-8">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(15,91,191,0.16),transparent_34%),radial-gradient(circle_at_top_right,rgba(17,24,39,0.08),transparent_28%),radial-gradient(circle_at_bottom_right,rgba(183,128,70,0.16),transparent_26%)]" />
          <div className="relative grid gap-6 xl:grid-cols-[1fr_320px]">
            <div>
              <div className="kicker mb-5">
                <Wand2 className="h-3.5 w-3.5" /> Vendor intelligence engine
              </div>
              <h1 className="section-heading">Search the furniture market like an AI sourcing desk.</h1>
              <p className="section-copy mt-4 max-w-3xl">
                Describe anything related to furniture in natural language. SPEC expands the brief into sourcing variants, scans vendor domains, verifies product pages where possible, and turns the market into a clean shortlist.
              </p>

              <form onSubmit={handleSubmit} className="mt-7 flex flex-col gap-3">
                <div className="relative">
                  <Sparkles className="absolute left-5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#0f5bbf]" />
                  <input
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder='Describe what you need - "modern sustainable swivel chair under $2k"...'
                    className="h-16 w-full rounded-[32px] border border-[#d8d0c3] bg-white/92 pl-12 pr-14 text-sm text-[#172033] shadow-[0_16px_42px_rgba(26,41,66,0.08)] outline-none transition-all focus:border-[#0f5bbf] focus:ring-4 focus:ring-[#0f5bbf]/10"
                  />
                  {inputValue && (
                    <button
                      type="button"
                      onClick={() => {
                        setInputValue("");
                        inputRef.current?.focus();
                      }}
                      className="absolute right-4 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full text-[#7c8595] transition-colors hover:bg-[#edf4fb] hover:text-[#172033]"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <div className="flex flex-col gap-3 sm:flex-row">
                  <Button type="submit" disabled={loading} className="h-12 px-6">
                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Run Search"}
                  </Button>
                  <Button variant="outline" type="button" className="h-12 px-6" onClick={handleSaveSearch}>
                    <BookmarkPlus className="h-4 w-4" /> Save Search
                  </Button>
                </div>
              </form>

              <div className="mt-5 flex flex-wrap gap-2">
                {EXAMPLE_SEARCHES.slice(0, 4).map((example) => (
                  <button
                    key={example}
                    onClick={() => {
                      setInputValue(example);
                      runSearch(example);
                    }}
                    className="rounded-full border border-[#ddd3c5] bg-white/80 px-3 py-1.5 text-xs font-medium text-[#5d6678] transition-colors hover:bg-[#edf4fb] hover:text-[#172033]"
                  >
                    "{example}"
                  </button>
                ))}
              </div>

              <div className="mt-6 grid gap-3 md:grid-cols-3">
                <SearchStatCard
                  icon={Compass}
                  title="Broad query coverage"
                  description="Loose briefs, exact SKUs, room concepts, materials, and style language all route into the same search engine."
                />
                <SearchStatCard
                  icon={Layers3}
                  title="Variant fanout"
                  description="One brief expands into multiple furniture-specific search variants before ranking begins."
                />
                <SearchStatCard
                  icon={ShieldCheck}
                  title="Trust-aware output"
                  description="Vendor images, links, and pricing only appear when they pass verification."
                />
              </div>
            </div>

            <WorkspaceSidebar
              recentSearches={recentSearches}
              savedSearches={savedSearches}
              favorites={favorites}
              onRunSearch={(value) => runSearch(value)}
              onRemoveSavedSearch={(value) => setSavedSearches(removeSavedSearch(value))}
            />
          </div>
        </section>

        {loading && (
          <div className="surface-panel mt-8 flex flex-col items-center justify-center gap-4 py-20 text-center">
            <div className="relative h-16 w-16">
              <div className="absolute inset-0 rounded-full border-4 border-[#0f5bbf]/10" />
              <div className="absolute inset-0 animate-spin rounded-full border-4 border-t-[#0f5bbf] border-r-transparent border-b-transparent border-l-transparent" />
              <Sparkles className="absolute inset-0 m-auto h-6 w-6 text-[#0f5bbf]" />
            </div>
            <div>
              <div className="text-lg font-semibold text-[#172033]">{loadingStage}</div>
              <div className="mt-1 text-sm text-[#677183]">Scanning manufacturer domains and product pages</div>
            </div>
          </div>
        )}

        {error && (
          <div className="surface-panel mt-8 py-16 text-center">
            <AlertCircle className="mx-auto mb-3 h-10 w-10 text-red-400" />
            <p className="text-red-500">{error}</p>
            <Button variant="outline" className="mt-4" onClick={() => runSearch(query)}>
              Retry
            </Button>
          </div>
        )}

        {!loading && !error && !searched && (
          <section className="mt-8 grid gap-6 lg:grid-cols-3">
            {[
              ["Coverage", "Query expansion + multi-vendor fanout bring much broader discovery than a single search query."],
              ["Credibility", "Vendor-page enrichment upgrades names, images, and canonical links before AI ranking."],
              ["Workflow", "Save, compare, favorite, and share without leaving the sourcing surface."],
            ].map(([title, description]) => (
              <div key={title} className="metric-card">
                <div className="text-lg font-semibold text-[#172033]">{title}</div>
                <div className="mt-2 text-sm leading-7 text-[#677183]">{description}</div>
              </div>
            ))}
          </section>
        )}

        {!loading && searched && !error && (
          <section className="mt-8 grid gap-6 xl:grid-cols-[1fr_320px]">
            <div>
              {intent && <IntentCard intent={intent} query={query} resultCount={results.length} diagnostics={diagnostics} onSaveSearch={handleSaveSearch} onCopySearchLink={handleCopySearchLink} sortBy={sortBy} setSortBy={setSortBy} />}
              {searchInsights && <SearchInsightsCard insights={searchInsights} onRunSearch={runSearch} />}
              {diagnostics && <SearchStatusBanner diagnostics={diagnostics} />}

              {results.length === 0 && (
                <div className="surface-panel py-20 text-center">
                  <Search className="mx-auto mb-4 h-12 w-12 text-[#c4c9d2]" />
                  <p className="text-lg text-[#50596b]">No matching products found</p>
                  <p className="mt-2 text-sm text-[#8a93a3]">Try a tighter product type, budget, or style phrase.</p>
                  <Button
                    variant="outline"
                    className="mt-5"
                    onClick={() => {
                      setSearched(false);
                      setInputValue("");
                      window.history.replaceState({}, "", "/Search");
                    }}
                  >
                    Clear search
                  </Button>
                </div>
              )}

              {sortedResults.length > 0 && (
                <>
                  {diagnostics && (
                    <div className="mb-4 flex flex-wrap gap-2">
                      {diagnostics.result_mode && <MetaPill label={formatResultMode(diagnostics.result_mode)} accent={diagnostics.result_mode === "verified-vendor-results"} />}
                      {typeof diagnostics.live_result_count === "number" && <MetaPill label={`Live ${diagnostics.live_result_count}`} />}
                      {typeof diagnostics.verified_result_count === "number" && <MetaPill label={`Verified ${diagnostics.verified_result_count}`} accent={diagnostics.verified_result_count > 0} />}
                      {diagnostics.fallback_to_catalog && <MetaPill label="Catalog fallback" />}
                      {diagnostics.domain_pool_size && <MetaPill label={`Vendor pool ${diagnostics.domain_pool_size}`} />}
                      {diagnostics.raw_count && <MetaPill label={`Candidates ${diagnostics.raw_count}`} />}
                      {diagnostics.enriched_count && <MetaPill label={`Enriched ${diagnostics.enriched_count}`} />}
                      {typeof diagnostics.discovered_count === "number" && <MetaPill label={`Discovered ${diagnostics.discovered_count}`} />}
                      {Array.isArray(diagnostics.query_variants) &&
                        diagnostics.query_variants.slice(0, 3).map((variant) => <MetaPill key={variant} label={variant} accent />)}
                    </div>
                  )}

                  {verifiedResults.length > 0 && (
                    <ResultSection
                      title="Verified vendor results"
                      description="These cards have a trusted vendor-hosted image and a direct vendor product link."
                      items={verifiedResults}
                      favorites={favorites}
                      compareItems={compareItems}
                      onToggleFavorite={handleToggleFavorite}
                      onToggleCompare={handleToggleCompare}
                    />
                  )}

                  {directionalResults.length > 0 && (
                    <ResultSection
                      title={verifiedResults.length > 0 ? "Directional matches" : "Directional shortlist"}
                      description="These are useful for sourcing direction, but they do not yet have a verified vendor photo and link pair."
                      items={directionalResults}
                      favorites={favorites}
                      compareItems={compareItems}
                      onToggleFavorite={handleToggleFavorite}
                      onToggleCompare={handleToggleCompare}
                    />
                  )}
                </>
              )}
            </div>

            <WorkspaceSidebar
              recentSearches={recentSearches}
              savedSearches={savedSearches}
              favorites={favorites}
              onRunSearch={(value) => runSearch(value)}
              onRemoveSavedSearch={(value) => setSavedSearches(removeSavedSearch(value))}
            />
          </section>
        )}
      </div>

      <CompareDrawer
        items={compareItems}
        onRemove={(id) => setCompareItems(removeCompareItem(id))}
        onClear={() => setCompareItems(clearCompareItems())}
      />
    </div>
  );
}

function SearchInsightsCard({ insights, onRunSearch }) {
  return (
    <div className="surface-panel-dark mb-6 p-5">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-blue-200">
        <Sparkles className="h-4 w-4" /> AI sourcing guidance
      </div>
      <div className="mt-3 text-2xl font-semibold tracking-[-0.04em] text-white">{insights.headline}</div>
      <p className="mt-2 text-sm leading-7 text-slate-300">{insights.summary}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {insights.signalPills.map((pill) => (
          <span key={pill} className="rounded-full border border-white/12 bg-white/8 px-3 py-1 text-xs font-medium text-white">
            {pill}
          </span>
        ))}
      </div>
      <div className="mt-4 rounded-[22px] border border-white/10 bg-white/6 p-4 text-sm leading-7 text-slate-200">
        {insights.recommendation}
      </div>
      {insights.coverageNote && (
        <div className="mt-4 flex items-start gap-2 rounded-[20px] border border-white/10 bg-[#0f1728]/60 px-4 py-3 text-sm text-slate-300">
          <Radar className="mt-0.5 h-4 w-4 shrink-0 text-blue-200" />
          <span>{insights.coverageNote}</span>
        </div>
      )}
      {insights.nextActions.length > 0 && (
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {insights.nextActions.map((action) => (
            <div key={action} className="rounded-[20px] border border-white/10 bg-[#0f1728]/60 px-4 py-3 text-sm text-slate-200">
              {action}
            </div>
          ))}
        </div>
      )}
      {insights.refinementPrompts?.length > 0 && (
        <div className="mt-4">
          <div className="mb-2 text-xs font-semibold uppercase tracking-[0.16em] text-blue-200">Suggested next searches</div>
          <div className="flex flex-wrap gap-2">
            {insights.refinementPrompts.map((prompt) => (
              <button
                key={prompt}
                onClick={() => onRunSearch(prompt)}
                className="rounded-full border border-white/12 bg-white/8 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-white/14"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MetaPill({ label, accent = false }) {
  return (
    <span className={`rounded-full px-3 py-1 text-xs font-medium ${accent ? "bg-[#edf4fb] text-[#0f5bbf]" : "bg-white/90 text-[#617082] border border-[#ddd3c5]"}`}>
      {label}
    </span>
  );
}

function SearchStatCard({ icon: Icon, title, description }) {
  return (
    <div className="rounded-[26px] border border-white/65 bg-white/70 p-4 shadow-[0_18px_40px_rgba(20,30,48,0.06)] backdrop-blur">
      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#edf4fb] text-[#0f5bbf]">
        <Icon className="h-4 w-4" />
      </div>
      <div className="mt-3 text-sm font-semibold text-[#172033]">{title}</div>
      <div className="mt-2 text-sm leading-6 text-[#667083]">{description}</div>
    </div>
  );
}

function SearchStatusBanner({ diagnostics }) {
  const isVerified = diagnostics.result_mode === "verified-vendor-results";
  const title = isVerified ? "Trusted vendor results are active." : "Search is operating in directional mode.";
  const description = isVerified
    ? "These results include verified vendor-hosted assets and direct product links."
    : "The engine is still finding market-relevant options, but verified vendor asset coverage is limited for this brief.";

  return (
    <div className={`mb-6 rounded-[28px] border p-5 ${isVerified ? "border-[#cfe8dc] bg-[#eef8f2]" : "border-[#e7dccd] bg-[#fbf6ef]"}`}>
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#7b6a52]">Search status</div>
          <div className="mt-2 text-lg font-semibold text-[#172033]">{title}</div>
          <div className="mt-1 text-sm text-[#667083]">{description}</div>
        </div>
        <div className="grid grid-cols-2 gap-3 md:min-w-[260px]">
          <StatusMetric label="Verified" value={diagnostics.verified_result_count || 0} />
          <StatusMetric label="Live" value={diagnostics.live_result_count || 0} />
        </div>
      </div>
    </div>
  );
}

function StatusMetric({ label, value }) {
  return (
    <div className="rounded-[20px] bg-white/80 px-4 py-3 text-center">
      <div className="text-[11px] uppercase tracking-[0.16em] text-[#8b93a3]">{label}</div>
      <div className="mt-1 text-lg font-semibold text-[#172033]">{value}</div>
    </div>
  );
}

function WorkspaceSidebar({ recentSearches, savedSearches, favorites, onRunSearch, onRemoveSavedSearch }) {
  return (
    <div className="space-y-4">
      <div className="surface-panel p-5">
        <div className="flex items-center gap-2">
          <BookmarkPlus className="h-4 w-4 text-[#0f5bbf]" />
          <h3 className="font-semibold text-[#172033]">Saved searches</h3>
        </div>
        <div className="mt-4 space-y-3">
          {savedSearches.length === 0 ? (
            <p className="text-sm leading-6 text-[#7e8796]">Save your strongest prompts to build a reusable sourcing playbook.</p>
          ) : (
            savedSearches.slice(0, 5).map((entry) => (
              <div key={entry.query} className="rounded-[22px] bg-[#f8f3eb] p-4">
                <button className="text-left text-sm font-semibold text-[#172033]" onClick={() => onRunSearch(entry.query)}>
                  {entry.query}
                </button>
                <div className="mt-1 text-xs leading-6 text-[#7b8394]">{entry.summary || `${entry.resultCount || 0} results last run`}</div>
                <button className="mt-2 text-xs font-medium text-[#8b93a3] hover:text-red-500" onClick={() => onRemoveSavedSearch(entry.query)}>
                  Remove
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="surface-panel p-5">
        <div className="flex items-center gap-2">
          <History className="h-4 w-4 text-[#0f5bbf]" />
          <h3 className="font-semibold text-[#172033]">Recent searches</h3>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {recentSearches.length === 0 ? (
            <p className="text-sm leading-6 text-[#7e8796]">Your recent prompts will appear here.</p>
          ) : (
            recentSearches.map((entry) => (
              <button
                key={entry}
                onClick={() => onRunSearch(entry)}
                className="rounded-full border border-[#ddd3c5] bg-white/85 px-3 py-1.5 text-xs font-medium text-[#5d6678] transition-colors hover:bg-[#edf4fb] hover:text-[#172033]"
              >
                {entry}
              </button>
            ))
          )}
        </div>
      </div>

      <div className="surface-panel-dark p-5">
        <div className="flex items-center gap-2 text-blue-100">
          <Heart className="h-4 w-4" />
          <h3 className="font-semibold text-white">Favorites</h3>
        </div>
        <div className="mt-4 space-y-3">
          {favorites.length === 0 ? (
            <p className="text-sm leading-6 text-slate-300">Favorite products to build a polished shortlist before compare or client review.</p>
          ) : (
            favorites.slice(0, 4).map((item) => (
              <div key={item.id} className="flex items-center gap-3 rounded-[20px] border border-white/10 bg-white/8 p-3">
                {item.thumbnail ? (
                  <img src={item.thumbnail} alt={item.product_name} className="h-12 w-12 rounded-2xl object-cover bg-white/10" />
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-slate-400">
                    <ImageOff className="h-4 w-4" />
                  </div>
                )}
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-white">{item.product_name}</div>
                  <div className="truncate text-xs text-slate-300">{item.manufacturer_name}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function IntentCard({ intent, query, resultCount, diagnostics, onSaveSearch, onCopySearchLink, sortBy, setSortBy }) {
  const [expanded, setExpanded] = useState(false);
  const tags = [
    intent.product_type && intent.product_type.replace(/_/g, " "),
    intent.style,
    intent.material,
    intent.color,
    intent.max_price ? `Under $${intent.max_price.toLocaleString()}` : null,
    intent.sustainable ? "Sustainable" : null,
    intent.ergonomic ? "Ergonomic" : null,
  ].filter(Boolean);

  return (
    <div className="surface-panel mb-6 p-5">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#2d6fb7]">
            <Sparkles className="h-4 w-4" /> AI understood your search
          </div>
          <h2 className="mt-3 font-['Iowan_Old_Style','Palatino_Linotype',Georgia,serif] text-2xl font-semibold text-[#172033]">
            {intent.summary}
          </h2>
          <p className="mt-2 text-sm text-[#677183]">
            {resultCount} results for "{query}"
            {diagnostics?.manufacturer_count ? ` across ${diagnostics.manufacturer_count} matched manufacturers.` : ""}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {tags.map((tag) => (
              <span key={tag} className="rounded-full bg-[#edf4fb] px-3 py-1 text-xs font-medium text-[#0f5bbf]">
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" className="gap-2" onClick={onSaveSearch}>
            <BookmarkPlus className="h-4 w-4" /> Save
          </Button>
          <Button variant="outline" size="sm" className="gap-2" onClick={onCopySearchLink}>
            <Share2 className="h-4 w-4" /> Share
          </Button>
          <button
            onClick={() => setSortBy("relevance")}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${sortBy === "relevance" ? "bg-[#172033] text-white" : "bg-[#f3ece2] text-[#5d6678]"}`}
          >
            Best match
          </button>
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-[#f3ece2] text-[#5d6678]"
          >
            {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="mt-4 grid gap-2 border-t border-[#ece3d6] pt-4 text-sm text-[#657082] sm:grid-cols-3">
          {intent.product_type && <div><span className="font-semibold text-[#172033]">Type:</span> {intent.product_type.replace(/_/g, " ")}</div>}
          {intent.style && <div><span className="font-semibold text-[#172033]">Style:</span> {intent.style}</div>}
          {intent.material && <div><span className="font-semibold text-[#172033]">Material:</span> {intent.material}</div>}
          {intent.color && <div><span className="font-semibold text-[#172033]">Color:</span> {intent.color}</div>}
          {intent.max_price && <div><span className="font-semibold text-[#172033]">Max price:</span> ${intent.max_price.toLocaleString()}</div>}
          {intent.max_lead_time_weeks && <div><span className="font-semibold text-[#172033]">Lead time:</span> ≤{intent.max_lead_time_weeks} weeks</div>}
        </div>
      )}
    </div>
  );
}

function ProductCard({ item, rank, isFavorite, isCompared, onToggleFavorite, onToggleCompare }) {
  const [imgError, setImgError] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const scoreBadge =
    item.relevance_score >= 90 ? "bg-[#e9f7ef] text-[#1f6f64]" :
    item.relevance_score >= 75 ? "bg-[#edf4fb] text-[#0f5bbf]" :
    "bg-[#f5efe6] text-[#8b5b2d]";
  const sourceBadge = getSourceBadge(item);

  return (
    <div className="surface-panel overflow-hidden p-0 transition-all hover:-translate-y-1">
      <div className="relative aspect-[4/3] overflow-hidden rounded-t-[28px] bg-[#ece7dd]">
        {item.image_url && !imgError ? (
          <>
            {!imgLoaded && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="h-5 w-5 animate-spin text-[#b4bcc8]" />
              </div>
            )}
            <img
              src={item.image_url}
              alt={item.product_name}
              className={`h-full w-full object-cover transition-transform duration-300 hover:scale-105 ${imgLoaded ? "opacity-100" : "opacity-0"}`}
              onLoad={() => setImgLoaded(true)}
              onError={() => setImgError(true)}
            />
          </>
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-[#b4bcc8]">
            <ImageOff className="h-7 w-7" />
            <span className="text-xs">{item.result_quality === "verified" ? "Image unavailable" : "Awaiting verified vendor image"}</span>
          </div>
        )}

        <div className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-semibold ${scoreBadge}`}>
          {item.relevance_score}% match
        </div>
        <div className={`absolute left-3 ${rank <= 3 ? "top-12" : "top-12"} rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] ${sourceBadge.className}`}>
          {sourceBadge.label}
        </div>
        {rank <= 3 && (
          <div className="absolute bottom-3 left-3 flex h-8 w-8 items-center justify-center rounded-full bg-[#172033] text-xs font-bold text-white">
            #{rank}
          </div>
        )}
        <div className="absolute right-3 top-3 flex gap-2">
          <button onClick={onToggleFavorite} className={`flex h-9 w-9 items-center justify-center rounded-full ${isFavorite ? "bg-[#d03b3b] text-white" : "bg-white/90 text-[#5f6879]"}`}>
            <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
          </button>
          <button onClick={onToggleCompare} className={`flex h-9 w-9 items-center justify-center rounded-full ${isCompared ? "bg-[#0f5bbf] text-white" : "bg-white/90 text-[#5f6879]"}`}>
            <GitCompare className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="p-5">
        <div className="text-[11px] uppercase tracking-[0.16em] text-[#8b93a3]">{item.manufacturer_name}</div>
        <div className="mt-2 line-clamp-2 text-lg font-semibold leading-7 text-[#172033]">{item.product_name}</div>

        {item.match_label && (
          <div className="mt-3 flex items-center gap-2 text-sm text-[#1f6f64]">
            <CheckCircle2 className="h-4 w-4" />
            <span className="font-medium">{item.match_label}</span>
          </div>
        )}

        {item.criteria_matched?.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {item.criteria_matched.slice(0, 3).map((criterion, index) => (
              <span key={`${criterion}-${index}`} className="rounded-full bg-[#f5efe6] px-2.5 py-1 text-xs font-medium capitalize text-[#8b5b2d]">
                {criterion.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        )}

        <div className="mt-4 text-sm leading-7 text-[#667083]">{item.reasoning || "Matched to your sourcing prompt."}</div>

        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <div className="rounded-[18px] bg-[#f8f3eb] px-3 py-2">
            <div className="text-[11px] uppercase tracking-[0.14em] text-[#8b93a3]">Confidence</div>
            <div className="mt-1 font-semibold text-[#172033]">{item.product_page_confidence ? `${item.product_page_confidence}%` : "Low"}</div>
          </div>
          <div className="rounded-[18px] bg-[#f8f3eb] px-3 py-2">
            <div className="text-[11px] uppercase tracking-[0.14em] text-[#8b93a3]">Lead time</div>
            <div className="mt-1 font-semibold text-[#172033]">{item.lead_time_weeks ? `${item.lead_time_weeks} weeks` : "Not surfaced"}</div>
          </div>
        </div>

        {item.price_verified && item.verified_price ? (
          <div className="mt-3 rounded-[18px] bg-[#edf8f4] px-3 py-2 text-sm">
            <div className="text-[11px] uppercase tracking-[0.14em] text-[#1f6f64]">Verified pricing</div>
            <div className="mt-1 font-semibold text-[#172033]">${Number(item.verified_price).toLocaleString()}</div>
          </div>
        ) : null}

        {(item.collection || item.sku) && (
          <div className="mt-3 flex flex-wrap gap-2">
            {item.collection ? <span className="rounded-full bg-[#edf4fb] px-2.5 py-1 text-xs font-medium text-[#0f5bbf]">{item.collection}</span> : null}
            {item.sku ? <span className="rounded-full bg-[#f4f0e8] px-2.5 py-1 text-xs font-medium text-[#7a6242]">SKU {item.sku}</span> : null}
          </div>
        )}

        <div className="mt-5 flex items-center justify-between gap-3">
          <div className="text-xs uppercase tracking-[0.16em] text-[#8b93a3]">{item.vendor_signals?.slice?.(0, 2)?.join(" · ") || item.source}</div>
          {item.portal_url ? (
            <a
              href={item.portal_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-sm font-semibold text-[#0f5bbf] hover:underline"
            >
              Visit <ExternalLink className="h-3.5 w-3.5" />
            </a>
          ) : (
            <span className="text-xs font-medium uppercase tracking-[0.16em] text-[#9ca5b4]">Link unavailable</span>
          )}
        </div>
      </div>
    </div>
  );
}

function getSourceBadge(item) {
  if (item.result_quality === "verified") {
    return {
      label: "Verified vendor",
      className: "bg-[#e9f7ef] text-[#1f6f64]",
    };
  }
  if (item.result_quality === "live-unverified") {
    return {
      label: "Live candidate",
      className: "bg-[#edf4fb] text-[#0f5bbf]",
    };
  }
  if (item.product_page_confidence >= 80) {
    return {
      label: "High confidence",
      className: "bg-[#e9f7ef] text-[#1f6f64]",
    };
  }
  if (item.product_page_confidence >= 55) {
    return {
      label: "Moderate confidence",
      className: "bg-[#edf4fb] text-[#0f5bbf]",
    };
  }
  return {
    label: "Directional",
    className: "bg-[#f5efe6] text-[#8b5b2d]",
  };
}

function ResultSection({ title, description, items, favorites, compareItems, onToggleFavorite, onToggleCompare }) {
  return (
    <div className="mb-6">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <div className="text-lg font-semibold text-[#172033]">{title}</div>
          <div className="mt-1 text-sm text-[#6a7385]">{description}</div>
        </div>
        <div className="text-xs font-semibold uppercase tracking-[0.16em] text-[#8b93a3]">{items.length} results</div>
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 2xl:grid-cols-3">
        {items.map((item, index) => (
          <ProductCard
            key={item.id || index}
            item={item}
            rank={index + 1}
            isFavorite={favorites.some((entry) => entry.id === item.id)}
            isCompared={compareItems.some((entry) => entry.id === item.id)}
            onToggleFavorite={() => onToggleFavorite(item)}
            onToggleCompare={() => onToggleCompare(item)}
          />
        ))}
      </div>
    </div>
  );
}

function formatResultMode(mode) {
  switch (mode) {
    case "verified-vendor-results":
      return "Verified vendor results";
    case "directional-catalog-fallback":
      return "Directional fallback";
    case "no-verified-results":
      return "No verified results";
    default:
      return mode;
  }
}
