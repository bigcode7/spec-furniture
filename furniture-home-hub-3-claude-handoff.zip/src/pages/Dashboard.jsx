import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Search, TrendingUp, Clock3, ArrowRight, Building2, Sparkles, Heart, BookmarkPlus, GitCompare, FolderOpen, Target } from "lucide-react";
import { getCompareItems, getFavorites, getRecentSearches, getSavedSearches } from "@/lib/growth-store";
import TrendAnalysisAgent from "@/components/agents/TrendAnalysisAgent";
import QuestionAnswerAgent from "@/components/agents/QuestionAnswerAgent";

export default function Dashboard() {
  const [listings, setListings] = useState([]);
  const [styles, setStyles] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [aiPanel, setAiPanel] = useState("concierge");
  const [workspaceStats, setWorkspaceStats] = useState({
    favorites: 0,
    savedSearches: 0,
    compareItems: 0,
    recentSearches: [],
  });

  useEffect(() => {
    Promise.all([
      base44.entities.ManufacturerListing.filter({ status: "active" }),
      base44.entities.FurnitureStyle.list(),
      base44.entities.Manufacturer.filter({ status: "active" }),
    ]).then(([l, s, m]) => {
      setListings(l);
      setStyles(s);
      setManufacturers(m);
      setLoading(false);
    });

    setWorkspaceStats({
      favorites: getFavorites().length,
      savedSearches: getSavedSearches().length,
      compareItems: getCompareItems().length,
      recentSearches: getRecentSearches(),
    });
  }, []);

  const topCommission = [...listings]
    .sort((a, b) => (b.wholesale_price * b.commission_rate) - (a.wholesale_price * a.commission_rate))
    .slice(0, 6);

  const fastestLeadTime = [...listings]
    .filter((listing) => listing.lead_time_max_weeks)
    .sort((a, b) => a.lead_time_max_weeks - b.lead_time_max_weeks)
    .slice(0, 6);

  const stats = [
    { label: "Manufacturer Listings", value: listings.length, tone: "text-[#0f5bbf]" },
    { label: "Furniture Styles", value: styles.length, tone: "text-[#172033]" },
    { label: "Active Manufacturers", value: manufacturers.length, tone: "text-[#1f6f64]" },
    { label: "Avg Commission", value: listings.length ? `${Math.round(listings.reduce((sum, listing) => sum + (listing.commission_rate || 0.1) * 100, 0) / listings.length)}%` : "—", tone: "text-[#b36f2d]" },
  ];

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) window.location.href = createPageUrl(`Search?q=${encodeURIComponent(query.trim())}`);
  };

  return (
    <div className="relative py-8 md:py-10">
      <div className="page-wrap">
        <section className="surface-panel relative overflow-hidden p-6 md:p-8 lg:p-10">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(15,91,191,0.12),transparent_36%),radial-gradient(circle_at_top_right,rgba(191,132,71,0.12),transparent_28%)]" />
          <div className="relative grid gap-8 lg:grid-cols-[1.05fr_0.95fr]">
            <div>
              <div className="kicker mb-5">
                <Sparkles className="h-3.5 w-3.5" /> Premium sourcing command center
              </div>
              <h1 className="section-heading max-w-3xl">
                A sharper dashboard for
                <span className="text-[#0f5bbf]"> faster furniture decisions.</span>
              </h1>
              <p className="section-copy mt-5 max-w-2xl">
                Search across vendor inventory, review your active sourcing pipeline, and move from discovery to compare to project handoff with less friction.
              </p>

              <form onSubmit={handleSearch} className="mt-7 flex flex-col gap-3 sm:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#7f8898]" />
                  <input
                    type="text"
                    placeholder='Try "emerald velvet sofa", "marble coffee table"...'
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="h-14 w-full rounded-full border border-[#d9d1c5] bg-white/90 pl-11 pr-4 text-sm text-[#172033] shadow-[0_14px_34px_rgba(26,41,66,0.06)] outline-none transition-all focus:border-[#0f5bbf] focus:ring-4 focus:ring-[#0f5bbf]/10"
                  />
                </div>
                <button type="submit" className="pill-button h-14 bg-[#172033] px-7 text-white shadow-[0_18px_42px_rgba(23,32,51,0.2)] hover:-translate-y-0.5">
                  Launch Search
                </button>
              </form>

              <div className="mt-5 flex flex-wrap gap-2">
                {["velvet sectional", "marble table", "mid-century chair", "outdoor sofa", "rattan bed"].map((term) => (
                  <Link
                    key={term}
                    to={createPageUrl(`Search?q=${encodeURIComponent(term)}`)}
                    className="rounded-full border border-[#ddd3c5] bg-white/80 px-3 py-1.5 text-xs font-medium text-[#566072] transition-colors hover:bg-[#edf4fb] hover:text-[#172033]"
                  >
                    {term}
                  </Link>
                ))}
              </div>
            </div>

            <div className="surface-panel-dark p-6">
              <div className="flex items-center gap-2 text-blue-100">
                <Target className="h-4 w-4" />
                <div className="text-xs uppercase tracking-[0.18em]">Active workspace</div>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-4">
                {[
                  { label: "Favorites", value: workspaceStats.favorites, icon: Heart },
                  { label: "Saved Searches", value: workspaceStats.savedSearches, icon: BookmarkPlus },
                  { label: "Compare Queue", value: workspaceStats.compareItems, icon: GitCompare },
                  { label: "Recent Prompts", value: workspaceStats.recentSearches.length, icon: FolderOpen },
                ].map((item) => (
                  <div key={item.label} className="rounded-[24px] border border-white/10 bg-white/8 p-4">
                    <item.icon className="h-4 w-4 text-blue-200" />
                    <div className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-white">{item.value}</div>
                    <div className="mt-1 text-sm text-slate-300">{item.label}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 space-y-3">
                {(workspaceStats.recentSearches.length ? workspaceStats.recentSearches.slice(0, 3) : ["velvet sectional", "marble coffee table", "boucle accent chair"]).map((term) => (
                  <Link
                    key={term}
                    to={createPageUrl(`Search?q=${encodeURIComponent(term)}`)}
                    className="block rounded-[22px] border border-white/10 bg-white/6 px-4 py-3 text-sm text-white/90 transition-colors hover:bg-white/12"
                  >
                    <div className="text-[11px] uppercase tracking-[0.16em] text-blue-200">Resume sourcing</div>
                    <div className="mt-1 font-medium">{term}</div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mt-8 grid gap-4 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="metric-card">
              <div className={`text-3xl font-semibold tracking-[-0.05em] ${stat.tone}`}>{loading ? "—" : stat.value}</div>
              <div className="mt-1 text-sm text-[#667083]">{stat.label}</div>
            </div>
          ))}
        </section>

        <section className="surface-panel-dark mt-8 p-6 md:p-7">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="flex items-center gap-2 text-blue-100">
                <Sparkles className="h-4 w-4" />
                <div className="text-xs uppercase tracking-[0.18em]">AI command center</div>
              </div>
              <h2 className="mt-3 font-['Iowan_Old_Style','Palatino_Linotype',Georgia,serif] text-3xl font-semibold tracking-[-0.04em] text-white">
                Put AI to work before you ever open a vendor tab.
              </h2>
              <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-300">
                Use SPEC as a sourcing copilot: interpret design intent, answer market questions, and track trend momentum without leaving the workflow.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                { id: "concierge", label: "AI Concierge" },
                { id: "trends", label: "Trend Radar" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setAiPanel(item.id)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                    aiPanel === item.id
                      ? "bg-white text-[#172033] shadow-[0_12px_28px_rgba(18,26,40,0.28)]"
                      : "border border-white/12 bg-white/6 text-slate-200 hover:bg-white/10"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {[
              ["Intent parsing", "Turn loose designer language into clearer sourcing strategy and follow-up prompts."],
              ["Trend intelligence", "Track whether materials, forms, and aesthetics are emerging, rising, or fading."],
              ["Commercial signal", "Keep margin, lead time, and manufacturer context near every recommendation."],
            ].map(([title, description]) => (
              <div key={title} className="rounded-[24px] border border-white/10 bg-white/6 p-4">
                <div className="text-sm font-semibold text-white">{title}</div>
                <div className="mt-2 text-sm leading-6 text-slate-300">{description}</div>
              </div>
            ))}
          </div>

          <div className="mt-6 rounded-[30px] border border-white/10 bg-[#0f1728]/60 p-4 md:p-5">
            {aiPanel === "concierge" ? <QuestionAnswerAgent /> : <TrendAnalysisAgent />}
          </div>
        </section>

        {loading ? (
          <div className="py-24 text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-[#0f5bbf]/15 border-t-[#0f5bbf]" />
          </div>
        ) : (
          <>
            <section className="mt-8 grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
              <div className="surface-panel p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs uppercase tracking-[0.18em] text-[#8b93a3]">Pipeline momentum</div>
                    <h2 className="mt-2 font-['Iowan_Old_Style','Palatino_Linotype',Georgia,serif] text-2xl font-semibold text-[#172033]">Your sourcing posture at a glance</h2>
                  </div>
                </div>
                <div className="mt-5 grid gap-4 sm:grid-cols-3">
                  {[
                    { label: "Favorites", value: workspaceStats.favorites, icon: Heart, tone: "bg-[#fff1f1] text-[#d03b3b]" },
                    { label: "Saved Searches", value: workspaceStats.savedSearches, icon: BookmarkPlus, tone: "bg-[#edf4fb] text-[#0f5bbf]" },
                    { label: "Compare Queue", value: workspaceStats.compareItems, icon: GitCompare, tone: "bg-[#edf8f4] text-[#1f6f64]" },
                  ].map((card) => (
                    <div key={card.label} className="rounded-[24px] bg-[#faf6ef] p-4">
                      <div className={`flex h-10 w-10 items-center justify-center rounded-2xl ${card.tone}`}>
                        <card.icon className="h-4 w-4" />
                      </div>
                      <div className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-[#172033]">{card.value}</div>
                      <div className="mt-1 text-sm text-[#667083]">{card.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="surface-panel-dark p-6">
                <div className="flex items-center gap-2 text-blue-100">
                  <Building2 className="h-4 w-4" />
                  <div className="text-xs uppercase tracking-[0.18em]">Partner network</div>
                </div>
                <div className="mt-4 text-3xl font-semibold tracking-[-0.05em] text-white">{manufacturers.length} active manufacturers</div>
                <p className="mt-2 text-sm leading-7 text-slate-300">
                  Browse manufacturer profiles, category breadth, and lead-time posture before pushing deeper into compare or project workflows.
                </p>
                <Link
                  to={createPageUrl("Manufacturers")}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-semibold text-[#172033] transition-transform hover:-translate-y-0.5"
                >
                  View manufacturers <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </section>

            <Section title="Top Commission Opportunities" icon={TrendingUp} linkTo="Search" linkLabel="See all" className="mt-10">
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
                {topCommission.map((listing) => (
                  <MiniCard key={listing.id} listing={listing} />
                ))}
              </div>
            </Section>

            <Section title="Fastest Lead Times" icon={Clock3} linkTo="Search?q=" linkLabel="Browse all" className="mt-10">
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
                {fastestLeadTime.map((listing) => (
                  <MiniCard key={listing.id} listing={listing} showLeadTime />
                ))}
              </div>
            </Section>
          </>
        )}
      </div>
    </div>
  );
}

function Section({ title, icon: Icon, linkTo, linkLabel, children, className = "" }) {
  return (
    <section className={className}>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-[0.18em] text-[#8b93a3]">Featured slice</div>
          <div className="mt-2 flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#edf4fb] text-[#0f5bbf]">
              <Icon className="h-4 w-4" />
            </div>
            <h2 className="font-['Iowan_Old_Style','Palatino_Linotype',Georgia,serif] text-2xl font-semibold text-[#172033]">{title}</h2>
          </div>
        </div>
        <Link to={createPageUrl(linkTo)} className="pill-button border border-[#d8d0c3] bg-white/85 text-[#172033] hover:-translate-y-0.5">
          {linkLabel} <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
      {children}
    </section>
  );
}

function MiniCard({ listing, showLeadTime = false }) {
  const [imgError, setImgError] = useState(false);
  const commission = Math.round(listing.wholesale_price * (listing.commission_rate || 0.1));

  return (
    <a
      href={listing.portal_url}
      target="_blank"
      rel="noopener noreferrer"
      className="surface-panel block overflow-hidden p-0 transition-all hover:-translate-y-1"
    >
      <div className="relative aspect-[4/3] overflow-hidden rounded-t-[28px] bg-[#ece7dd]">
        {listing.image_url && !imgError ? (
          <img
            src={listing.image_url}
            alt={listing.product_name}
            className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xs text-[#949cab]">No image</div>
        )}
        <div className="absolute right-3 top-3 rounded-full bg-[#172033] px-3 py-1 text-[11px] font-semibold text-white shadow-[0_10px_24px_rgba(23,32,51,0.22)]">
          {showLeadTime ? `${listing.lead_time_min_weeks}–${listing.lead_time_max_weeks}wk` : `+$${commission.toLocaleString()}`}
        </div>
      </div>
      <div className="p-4">
        <div className="text-[11px] uppercase tracking-[0.16em] text-[#8b93a3]">{listing.manufacturer_name}</div>
        <div className="mt-2 line-clamp-2 text-sm font-semibold leading-6 text-[#172033]">{listing.product_name}</div>
        <div className="mt-2 text-sm text-[#5f6879]">${listing.wholesale_price?.toLocaleString()}</div>
      </div>
    </a>
  );
}
