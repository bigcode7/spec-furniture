import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Search, ArrowRight, Zap, TrendingUp, Clock3, ShieldCheck, Sparkles, Building2 } from "lucide-react";

export default function Landing() {
  const highlights = [
    { icon: Search, title: "Cross-vendor discovery", desc: "Search across manufacturer domains, product pages, and visual results with AI-ranked matches." },
    { icon: TrendingUp, title: "Commercial intelligence", desc: "See commission opportunity, sourcing momentum, and shortlist signal before opening vendor sites." },
    { icon: Clock3, title: "Faster sourcing loops", desc: "Saved searches, compare flows, and project handoff keep teams moving without spreadsheet churn." },
    { icon: ShieldCheck, title: "Direct manufacturer routing", desc: "Link straight to manufacturer product pages instead of lossy marketplace intermediaries." },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#fbf7f0] hero-noise">
      <div className="absolute inset-0 soft-grid opacity-[0.18]" />
      <div className="relative">
        <header className="page-wrap pt-6">
          <div className="surface-panel flex items-center justify-between px-5 py-4">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#172033] text-white">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <div className="font-['Iowan_Old_Style','Palatino_Linotype',Georgia,serif] text-xl font-semibold tracking-[-0.04em] text-[#172033]">
                  SPEC
                </div>
                <div className="text-[11px] uppercase tracking-[0.18em] text-[#7b8494]">Furniture intelligence platform</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to={createPageUrl("Dashboard")} className="pill-button bg-[#172033] text-white shadow-[0_16px_36px_rgba(23,32,51,0.2)] hover:-translate-y-0.5">
                Enter Platform <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </header>

        <main className="page-wrap py-10 md:py-14">
          <section className="grid items-end gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div className="surface-panel relative overflow-hidden p-8 md:p-12">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(15,91,191,0.12),transparent_34%),radial-gradient(circle_at_bottom_right,rgba(195,136,76,0.14),transparent_28%)]" />
              <div className="relative">
                <div className="kicker mb-6">
                  <Zap className="h-3.5 w-3.5" /> Built for interior designers, retailers, and sourcing teams
                </div>
                <h1 className="max-w-4xl text-5xl font-semibold leading-[0.95] tracking-[-0.05em] text-[#172033] md:text-7xl">
                  Source beautifully.
                  <br />
                  Route decisively.
                  <br />
                  <span className="text-[#0f5bbf]">Present like a premium studio.</span>
                </h1>
                <p className="mt-6 max-w-2xl text-base leading-8 text-[#5e6778] md:text-lg">
                  SPEC is an AI-native sourcing platform for furniture teams who need sharper search, cleaner vendor discovery,
                  faster product intelligence, stronger project handoff, and a more credible client-facing workflow.
                </p>
                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <Link
                    to={createPageUrl("Search")}
                    className="pill-button bg-[#0f5bbf] text-white shadow-[0_18px_42px_rgba(15,91,191,0.22)] hover:-translate-y-0.5"
                  >
                    <Search className="h-4 w-4" /> Launch AI Search
                  </Link>
                  <Link
                    to={createPageUrl("Dashboard")}
                    className="pill-button border border-[#d8d0c3] bg-white text-[#172033] hover:-translate-y-0.5"
                  >
                    View Dashboard <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>

                <div className="mt-10 grid gap-4 md:grid-cols-3">
                  {[
                    ["Advanced retrieval", "AI search interprets natural-language design briefs, expands the query, and ranks vendor matches."],
                    ["Agent layer", "Trend radar and AI concierge surfaces help teams reason through sourcing strategy, not just search results."],
                    ["Commercial clarity", "Commission, lead time, and vendor coverage stay visible without breaking flow."],
                  ].map(([title, desc]) => (
                    <div key={title} className="rounded-[24px] border border-white/70 bg-white/80 p-4 shadow-[0_12px_36px_rgba(26,41,66,0.06)]">
                      <div className="text-sm font-semibold text-[#172033]">{title}</div>
                      <div className="mt-2 text-sm leading-6 text-[#687283]">{desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-5">
              <div className="surface-panel-dark p-7">
                <div className="flex items-center gap-2 text-blue-100">
                  <Building2 className="h-4 w-4" />
                  <span className="text-xs uppercase tracking-[0.18em]">Platform signal</span>
                </div>
                <div className="mt-5 grid grid-cols-2 gap-4">
                  {[
                    ["AI vendor search", "Natural language"],
                    ["Product enrichment", "Page + schema"],
                    ["AI copilots", "Trend + strategy"],
                    ["Deep linking", "Direct to source"],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-[22px] border border-white/10 bg-white/6 p-4">
                      <div className="text-2xl font-semibold tracking-[-0.04em] text-white">{value}</div>
                      <div className="mt-1 text-sm text-slate-300">{label}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="surface-panel p-6">
                <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8b93a3]">Why it feels different</div>
                <div className="mt-4 space-y-4">
                  {highlights.map((item) => (
                    <div key={item.title} className="flex items-start gap-4">
                      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#edf4fb] text-[#0f5bbf]">
                        <item.icon className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-[#172033]">{item.title}</div>
                        <div className="mt-1 text-sm leading-6 text-[#687283]">{item.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
