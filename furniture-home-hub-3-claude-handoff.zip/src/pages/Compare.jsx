import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { GitCompare, ExternalLink, Search, X, TrendingUp, ImageOff, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { clearCompareItems, getCompareItems } from "@/lib/growth-store";
import { buildCompareInsights } from "@/lib/ai-assist";

export default function Compare() {
  const [listings, setListings] = useState([]);
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check URL params for pre-selected items
    const params = new URLSearchParams(window.location.search);
    const ids = params.get("ids")?.split(",").filter(Boolean) || [];
    const storedCompareItems = getCompareItems();
    base44.entities.ManufacturerListing.filter({ status: "active" }).then(l => {
      setListings(l);
      if (ids.length) {
        const matched = l.filter(listing => ids.includes(listing.id));
        setSelected(matched.length ? matched : storedCompareItems);
      } else {
        setSelected(storedCompareItems);
      }
      setLoading(false);
    });
  }, []);

  const filtered = listings.filter(l =>
    !selected.find(s => s.id === l.id) &&
    (
      (l.style_name || "").toLowerCase().includes(search.toLowerCase()) ||
      (l.manufacturer_name || "").toLowerCase().includes(search.toLowerCase()) ||
      (l.product_name || "").toLowerCase().includes(search.toLowerCase())
    )
  ).slice(0, 12);
  const insights = buildCompareInsights(selected);

  const addToCompare = (listing) => {
    if (selected.length < 4) setSelected([...selected, listing]);
  };
  const removeFromCompare = (id) => {
    const next = selected.filter(s => s.id !== id);
    setSelected(next);
    window.localStorage.setItem("spec_growth_compare_items", JSON.stringify(next));
  };

  useEffect(() => {
    window.localStorage.setItem("spec_growth_compare_items", JSON.stringify(selected));
  }, [selected]);

  const SPEC_ROWS = [
    { label: "Manufacturer", key: "manufacturer_name" },
    { label: "Wholesale Price", key: "wholesale_price", format: v => v ? `$${v.toLocaleString()}` : "—" },
    { label: "Retail Price", key: "retail_price", format: v => v ? `$${v.toLocaleString()}` : "—" },
    { label: "Commission", render: l => `$${Math.round(l.wholesale_price * (l.commission_rate || 0.1)).toLocaleString()} (${Math.round((l.commission_rate || 0.1) * 100)}%)` },
    { label: "Lead Time", render: l => l.lead_time_min_weeks ? `${l.lead_time_min_weeks}–${l.lead_time_max_weeks} wks` : "—" },
    { label: "Material", key: "material" },
    { label: "Dimensions", key: "dimensions_summary" },
    { label: "Colors", render: l => (l.colors_available || []).join(", ") || "—" },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F7] p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <GitCompare className="w-6 h-6 text-[#0066CC]" />
          <h1 className="text-2xl font-black text-[#111]">Compare Listings</h1>
          <span className="text-sm text-gray-400">{selected.length}/4 selected</span>
        </div>

        {/* Add to compare search */}
        {selected.length < 4 && (
          <div className="bg-white rounded-2xl border border-gray-100 p-5 mb-6">
            <div className="text-sm font-semibold text-gray-700 mb-3">Add listings to compare</div>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search by style, manufacturer, or product name..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-sm border border-gray-200 rounded-xl bg-gray-50 focus:outline-none focus:border-[#0066CC]"
              />
            </div>
            {search && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {loading ? (
                  <div className="col-span-full text-sm text-gray-400 text-center py-4">Loading...</div>
                ) : filtered.length === 0 ? (
                  <div className="col-span-full text-sm text-gray-400 text-center py-4">No results for "{search}"</div>
                ) : filtered.map(l => (
                  <button
                    key={l.id}
                    onClick={() => addToCompare(l)}
                    className="text-left border border-gray-100 rounded-xl p-3 hover:border-[#0066CC] hover:bg-blue-50/30 transition-all group"
                  >
                    <div className="text-xs font-bold text-[#0066CC] mb-0.5">{l.manufacturer_name}</div>
                    <div className="text-xs font-medium text-gray-700 leading-tight">{l.product_name}</div>
                    <div className="text-xs text-gray-400 mt-1">{l.style_name} · ${l.wholesale_price?.toLocaleString()}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Compare table */}
        {selected.length === 0 ? (
          <div className="text-center py-20">
            <GitCompare className="w-14 h-14 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-500 text-lg mb-2">No listings selected</p>
            <p className="text-gray-400 text-sm mb-6">Search above to add up to 4 listings to compare side-by-side</p>
            <Link to={createPageUrl("Search")}>
              <Button variant="outline">Browse Listings</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-5">
            {insights && (
              <div className="rounded-2xl border border-[#d8dfea] bg-[linear-gradient(135deg,#0f1728_0%,#172033_55%,#1e3557_100%)] p-5 text-white">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-blue-200">
                  <Sparkles className="h-4 w-4" /> AI shortlist intelligence
                </div>
                <div className="mt-3 text-2xl font-semibold tracking-[-0.04em]">{insights.headline}</div>
                <p className="mt-2 max-w-3xl text-sm leading-7 text-slate-300">{insights.recommendation}</p>
                <div className="mt-5 grid gap-3 md:grid-cols-3">
                  {insights.highlights.map((item) => (
                    <div key={item.label} className="rounded-2xl border border-white/10 bg-white/6 p-4">
                      <div className="text-[11px] uppercase tracking-[0.16em] text-blue-200">{item.label}</div>
                      <div className="mt-2 text-sm font-medium text-white">{item.value}</div>
                    </div>
                  ))}
                </div>
                {insights.signals.length > 0 && (
                  <div className="mt-5 space-y-2">
                    {insights.signals.map((signal) => (
                      <div key={signal} className="rounded-xl bg-white/6 px-4 py-3 text-sm text-slate-200">
                        {signal}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              {/* Header row */}
              <div className={`grid gap-0 border-b border-gray-100`} style={{ gridTemplateColumns: `180px repeat(${selected.length}, 1fr)` }}>
                <div className="p-4 bg-gray-50" />
                {selected.map(l => (
                  <CompareHeader key={l.id} listing={l} onRemove={() => removeFromCompare(l.id)} />
                ))}
              </div>

              {/* Spec rows */}
              {SPEC_ROWS.map((row, i) => (
                <div
                  key={i}
                  className={`grid gap-0 border-b border-gray-50 ${i % 2 === 0 ? "" : "bg-gray-50/50"}`}
                  style={{ gridTemplateColumns: `180px repeat(${selected.length}, 1fr)` }}
                >
                  <div className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center">{row.label}</div>
                  {selected.map(l => (
                    <div key={l.id} className="p-4 text-sm text-gray-700 border-l border-gray-100">
                      {row.render ? row.render(l) : row.format ? row.format(l[row.key]) : (l[row.key] || "—")}
                    </div>
                  ))}
                </div>
              ))}

              {/* CTA row */}
              <div className="grid gap-0" style={{ gridTemplateColumns: `180px repeat(${selected.length}, 1fr)` }}>
                <div className="p-4" />
                {selected.map(l => (
                  <div key={l.id} className="p-4 border-l border-gray-100">
                    <a
                      href={l.portal_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 w-full bg-[#0066CC] hover:bg-[#0055AA] text-white text-sm font-semibold py-2.5 rounded-xl transition-colors"
                    >
                      Visit <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        {selected.length > 0 && (
          <div className="mt-4 flex justify-end">
            <button
              onClick={() => {
                setSelected(clearCompareItems());
              }}
              className="text-sm text-gray-400 hover:text-gray-700"
            >
              Clear compare list
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function CompareHeader({ listing, onRemove }) {
  const [imgError, setImgError] = useState(false);
  const commission = Math.round(listing.wholesale_price * (listing.commission_rate || 0.1));

  return (
    <div className="p-4 border-l border-gray-100">
      <div className="relative aspect-video bg-gray-100 rounded-xl overflow-hidden mb-3">
        {listing.image_url && !imgError ? (
          <img src={listing.image_url} alt={listing.product_name} className="w-full h-full object-cover" onError={() => setImgError(true)} />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ImageOff className="w-6 h-6 text-gray-300" />
          </div>
        )}
        <button onClick={onRemove} className="absolute top-2 right-2 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow hover:bg-red-50 hover:text-red-500 transition-colors">
          <X className="w-3 h-3" />
        </button>
      </div>
      <div className="text-xs font-bold text-[#0066CC] mb-0.5">{listing.manufacturer_name}</div>
      <div className="text-sm font-semibold text-[#111] leading-snug mb-2">{listing.product_name}</div>
      <div className="flex items-center gap-3 text-xs">
        <span className="font-bold text-[#111]">${listing.wholesale_price?.toLocaleString()}</span>
        <span className="text-green-600 flex items-center gap-0.5">
          <TrendingUp className="w-3 h-3" />+${commission.toLocaleString()}
        </span>
      </div>
    </div>
  );
}
