import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Plus, FolderOpen, ArrowRight, CheckCircle, Clock, Send, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { buildProjectInsights } from "@/lib/ai-assist";

const STATUS_CONFIG = {
  in_progress: { label: "In Progress", color: "bg-blue-100 text-blue-700", icon: Clock },
  sent_to_client: { label: "Sent to Client", color: "bg-yellow-100 text-yellow-700", icon: Send },
  approved: { label: "Approved", color: "bg-green-100 text-green-700", icon: CheckCircle },
  ordered: { label: "Ordered", color: "bg-purple-100 text-purple-700", icon: CheckCircle },
  completed: { label: "Completed", color: "bg-gray-100 text-gray-700", icon: CheckCircle },
};

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [showNewProject, setShowNewProject] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [form, setForm] = useState({ title: "", client_name: "", client_email: "", room_type: "", budget: "", notes: "" });
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      return base44.entities.Project.filter({ designer_id: u.id }, "-updated_date");
    }).then(setProjects).catch(() => {});
  }, []);

  const handleCreate = async () => {
    setSaving(true);
    const created = await base44.entities.Project.create({
      ...form,
      budget: parseFloat(form.budget) || 0,
      total_cost: 0,
      status: "in_progress",
      designer_id: user?.id,
      designer_name: user?.full_name || user?.email,
      items: [],
    });
    setProjects([created, ...projects]);
    setShowNewProject(false);
    setForm({ title: "", client_name: "", client_email: "", room_type: "", budget: "", notes: "" });
    setSelectedProject(created);
    setSaving(false);
  };

  if (selectedProject) {
    return <ProjectDetail project={selectedProject} onBack={() => setSelectedProject(null)} toast={toast} />;
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#222222]">My Projects</h1>
            <p className="text-gray-500 mt-1">{projects.length} active projects</p>
          </div>
          <Button className="bg-[#0066CC] hover:bg-[#0055AA] text-white gap-2" onClick={() => setShowNewProject(true)}>
            <Plus className="w-4 h-4" /> New Project
          </Button>
        </div>

        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
          {projects.map((p) => {
            const statusCfg = STATUS_CONFIG[p.status] || STATUS_CONFIG.in_progress;
            const progress = p.budget > 0 ? (p.total_cost / p.budget) * 100 : 0;
            return (
              <div key={p.id} className="bg-white rounded-xl border border-gray-100 p-6 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedProject(p)}>
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 bg-[#F0F7FF] rounded-xl flex items-center justify-center">
                    <FolderOpen className="w-5 h-5 text-[#0066CC]" />
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusCfg.color}`}>{statusCfg.label}</span>
                </div>
                <h3 className="font-bold text-[#222222] mb-1">{p.title}</h3>
                <div className="text-sm text-gray-500 mb-4">{p.client_name} · {p.room_type.replace(/_/g, " ")}</div>

                {/* Budget bar */}
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Budget used</span>
                    <span>${p.total_cost.toLocaleString()} / ${p.budget.toLocaleString()}</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${progress > 90 ? "bg-red-400" : progress > 70 ? "bg-yellow-400" : "bg-[#0066CC]"}`}
                      style={{ width: `${Math.min(progress, 100)}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>{p.items?.length || 0} items</span>
                  <span>Updated {p.updated_date}</span>
                </div>

                <div className="mt-4 flex items-center text-[#0066CC] text-sm font-medium">
                  Open project <ArrowRight className="w-3 h-3 ml-1" />
                </div>
              </div>
            );
          })}

          {/* New project card */}
          <button
            onClick={() => setShowNewProject(true)}
            className="bg-white rounded-xl border-2 border-dashed border-gray-200 p-6 hover:border-[#0066CC] hover:bg-[#F0F7FF] transition-all text-center group"
          >
            <div className="w-10 h-10 bg-gray-100 group-hover:bg-[#0066CC] rounded-xl flex items-center justify-center mx-auto mb-3 transition-colors">
              <Plus className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
            </div>
            <div className="font-medium text-gray-500 group-hover:text-[#0066CC]">Create New Project</div>
          </button>
        </div>
      </div>

      {/* New Project Dialog */}
      <Dialog open={showNewProject} onOpenChange={setShowNewProject}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Project</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label>Project Title</Label>
              <Input placeholder="e.g. Sarah Johnson - Living Room" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Client Name</Label>
                <Input placeholder="Client name" value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Client Email</Label>
                <Input placeholder="client@email.com" value={form.client_email} onChange={(e) => setForm({ ...form, client_email: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Room Type</Label>
                <Select value={form.room_type} onValueChange={(v) => setForm({ ...form, room_type: v })}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select room" /></SelectTrigger>
                  <SelectContent>
                    {["living_room", "bedroom", "dining_room", "office", "outdoor", "other"].map(r => (
                      <SelectItem key={r} value={r}>{r.replace(/_/g, " ")}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Budget ($)</Label>
                <Input type="number" placeholder="15000" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea placeholder="Client preferences, style notes..." value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1" />
            </div>
            <Button onClick={handleCreate} disabled={saving} className="w-full bg-[#0066CC] hover:bg-[#0055AA] text-white">
              {saving ? "Creating..." : "Create Project"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ProjectDetail({ project, onBack, toast }) {
  const [items, setItems] = useState(project.items || []);
  const total = items.reduce((sum, i) => sum + (i.price * i.quantity), 0);
  const remaining = project.budget - total;
  const aiInsights = buildProjectInsights(project, items);
  const copyClientBrief = async () => {
    const lines = [
      `Project: ${project.title}`,
      `Client: ${project.client_name}`,
      `Room: ${project.room_type.replace(/_/g, " ")}`,
      `Budget: $${project.budget.toLocaleString()}`,
      `Specified total: $${total.toLocaleString()}`,
      "",
      "Items:",
      ...(items.length
        ? items.map((item) => `- ${item.product_name} by ${item.manufacturer_name} x${item.quantity} ($${((item.price || 0) * item.quantity).toLocaleString()})`)
        : ["- No items added yet"]),
    ];
    await navigator.clipboard.writeText(lines.join("\n"));
    toast({
      title: "Client brief copied",
      description: "Use it in email, Slack, or your proposal doc.",
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] p-6">
      <div className="max-w-5xl mx-auto">
        <button onClick={onBack} className="flex items-center gap-2 text-sm text-gray-500 hover:text-[#0066CC] mb-6">
          ← Back to Projects
        </button>

        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-[#222222]">{project.title}</h1>
            <p className="text-gray-500">{project.client_name} · {project.room_type.replace(/_/g, " ")}</p>
          </div>
          <div className="flex gap-3">
            <Link to={createPageUrl("Search")}>
              <Button variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Add Furniture
              </Button>
            </Link>
            <Button variant="outline" className="gap-2" onClick={copyClientBrief}>
              <Copy className="w-4 h-4" /> Copy Client Brief
            </Button>
            <Button className="bg-[#0066CC] hover:bg-[#0055AA] text-white gap-2">
              <Send className="w-4 h-4" /> Send to Client
            </Button>
          </div>
        </div>

        {/* Budget overview */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl p-5 border border-gray-100">
            <div className="text-sm text-gray-500 mb-1">Total Budget</div>
            <div className="text-2xl font-bold text-[#222222]">${project.budget.toLocaleString()}</div>
          </div>
          <div className="bg-white rounded-xl p-5 border border-gray-100">
            <div className="text-sm text-gray-500 mb-1">Spec'd So Far</div>
            <div className="text-2xl font-bold text-[#0066CC]">${total.toLocaleString()}</div>
          </div>
          <div className={`rounded-xl p-5 border ${remaining >= 0 ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100"}`}>
            <div className="text-sm text-gray-500 mb-1">Remaining</div>
            <div className={`text-2xl font-bold ${remaining >= 0 ? "text-green-600" : "text-red-500"}`}>
              {remaining >= 0 ? `$${remaining.toLocaleString()}` : `-$${Math.abs(remaining).toLocaleString()}`}
            </div>
          </div>
        </div>

        <div className="mb-6 rounded-xl border border-[#d9e2ef] bg-[linear-gradient(135deg,#f4f8fc_0%,#eef5ff_100%)] p-6">
          <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0f5bbf]">AI project guidance</div>
          <h2 className="mt-2 text-xl font-bold text-[#172033]">Keep the project commercially sharp.</h2>
          <p className="mt-2 text-sm leading-7 text-[#5d6678]">{aiInsights.summary}</p>

          {aiInsights.nextActions.length > 0 && (
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {aiInsights.nextActions.map((action) => (
                <div key={action} className="rounded-xl bg-white/80 px-4 py-3 text-sm text-[#172033] shadow-[0_10px_24px_rgba(26,41,66,0.05)]">
                  {action}
                </div>
              ))}
            </div>
          )}

          {aiInsights.riskFlags.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {aiInsights.riskFlags.map((risk) => (
                <span key={risk} className="rounded-full bg-[#172033] px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-white">
                  {risk}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Items */}
        <div className="bg-white rounded-xl border border-gray-100 p-6">
          <h2 className="font-bold text-[#222222] mb-4">Spec'd Items ({items.length})</h2>
          {items.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <FolderOpen className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p>No items yet. Add furniture from the search page.</p>
              <Link to={createPageUrl("Search")}>
                <Button className="mt-4 bg-[#0066CC] text-white">Browse Furniture</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {items.map((item, i) => (
                <div key={i} className="flex items-center gap-4 p-3 rounded-lg border border-gray-100 hover:bg-gray-50">
                  <img src={item.thumbnail} alt={item.product_name} className="w-16 h-12 object-cover rounded-lg" />
                  <div className="flex-1">
                    <div className="font-medium text-sm">{item.product_name}</div>
                    <div className="text-xs text-gray-400">{item.manufacturer_name} · Ships in {item.lead_time_weeks}wk</div>
                  </div>
                  <div className="text-sm text-gray-500">Qty: {item.quantity}</div>
                  <div className="font-bold text-[#0066CC]">${(item.price * item.quantity).toLocaleString()}</div>
                </div>
              ))}
              <div className="flex justify-end pt-3 border-t border-gray-100">
                <div className="text-right">
                  <div className="text-sm text-gray-500">Project Total</div>
                  <div className="text-2xl font-bold text-[#0066CC]">${total.toLocaleString()}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
