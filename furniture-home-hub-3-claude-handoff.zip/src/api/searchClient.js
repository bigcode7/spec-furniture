import { base44 } from "@/api/base44Client";

const externalSearchServiceUrl = import.meta.env.VITE_SEARCH_SERVICE_URL;

export async function searchProducts(query) {
  if (externalSearchServiceUrl) {
    const response = await fetch(`${externalSearchServiceUrl.replace(/\/$/, "")}/search`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        query,
        search_mode: "balanced",
        max_vendors: 6,
        per_vendor: 2,
        discovery_timeout_ms: 4200,
      }),
    });

    if (!response.ok) {
      throw new Error(`search service error: ${response.status}`);
    }

    const data = await response.json();
    return {
      ...data,
      products: Array.isArray(data.products) ? data.products.map(normalizeStandaloneResult) : [],
    };
  }

  const response = await base44.functions.invoke("aiSearchProducts", { query });
  return response.data;
}

function normalizeStandaloneResult(item) {
  const isLiveResult = item.ingestion_source === "live-crawler" || item.ingestion_source === "live-discovery";
  const isVendorHostedImage = isLiveResult && item.image_verified && Boolean(item.image_url);
  const hasTrustedVendorUrl = isLiveResult && item.product_url_verified && isVendorAssetUrl(item.product_url, item.vendor_domain);
  const verifiedPrice = item.price_verified ? (item.wholesale_price ?? item.retail_price ?? null) : null;
  const confidence = Number(item.retrieval_quality_score || 0);

  return {
    id: item.id,
    product_name: item.product_name,
    manufacturer_name: item.vendor_name,
    portal_url: hasTrustedVendorUrl ? item.product_url : "",
    image_url: isVendorHostedImage ? item.image_url : "",
    thumbnail_url: isVendorHostedImage ? item.image_url : "",
    snippet: item.description,
    source: item.ingestion_source || "search-service",
    query_used: "",
    material: item.material,
    product_type: item.category,
    wholesale_price: item.price_verified ? item.wholesale_price : null,
    retail_price: item.price_verified ? item.retail_price : null,
    price_verified: Boolean(item.price_verified),
    lead_time_weeks: item.lead_time_weeks,
    relevance_score: item.relevance_score,
    criteria_matched: item.tags || [],
    criteria_missed: [],
    reasoning: item.reasoning || item.description || "Catalog match",
    match_label: hasTrustedVendorUrl && isVendorHostedImage
      ? "Verified vendor result"
      : isLiveResult
        ? "Live result pending verification"
        : "Directional catalog match",
    domain: item.vendor_domain,
    product_page_confidence: confidence,
    vendor_signals: [item.vendor_name, ...(item.retrieval_signals || []), item.ingestion_source].filter(Boolean),
    image_verified: Boolean(item.image_verified),
    product_url_verified: Boolean(item.product_url_verified),
    verified_price: verifiedPrice,
    result_quality: hasTrustedVendorUrl && isVendorHostedImage ? "verified" : isLiveResult ? "live-unverified" : "directional",
    sku: item.sku || "",
    collection: item.collection || "",
  };
}

function isVendorAssetUrl(url, vendorDomain) {
  if (!url || !vendorDomain) return false;
  try {
    return new URL(url).hostname.includes(vendorDomain.replace(/^www\./, ""));
  } catch {
    return false;
  }
}
