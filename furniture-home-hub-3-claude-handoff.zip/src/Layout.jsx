import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Search, GitCompare, Home, LogOut, Building2, FolderOpen, ClipboardList, Package2, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useState, useEffect } from "react";

const BASE_NAV_ITEMS = [
  { label: "Home", path: "Dashboard", icon: Home },
  { label: "Search", path: "Search", icon: Search },
  { label: "Compare", path: "Compare", icon: GitCompare },
  { label: "Manufacturers", path: "Manufacturers", icon: Building2 },
];

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const navItems = [
    ...BASE_NAV_ITEMS,
    ...(user?.role === "designer" ? [{ label: "Projects", path: "Projects", icon: FolderOpen }] : []),
    ...(user?.role === "manufacturer" || user?.role === "admin" ? [{ label: "Catalog", path: "ManufacturerCatalog", icon: Package2 }] : []),
    ...(user?.role ? [{ label: "Orders", path: "Orders", icon: ClipboardList }] : []),
  ];

  if (currentPageName === "Landing") return <>{children}</>;

  return (
    <div className="min-h-screen text-[#172033]">
      <header className="glass-header sticky top-0 z-40">
        <div className="page-wrap">
          <div className="flex min-h-[78px] items-center justify-between gap-4">
            <Link to={createPageUrl("Landing")} className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#172033] text-white shadow-[0_16px_40px_rgba(23,32,51,0.18)]">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <div className="font-['Iowan_Old_Style','Palatino_Linotype',Georgia,serif] text-xl font-semibold tracking-[-0.04em] text-[#172033]">
                  SPEC
                </div>
                <div className="text-[11px] uppercase tracking-[0.18em] text-[#7e8796]">Furniture Intelligence</div>
              </div>
            </Link>

            <nav className="hidden xl:flex items-center gap-2 rounded-full border border-white/70 bg-white/75 p-2 shadow-[0_14px_40px_rgba(26,41,66,0.08)] backdrop-blur-xl">
              {navItems.map((item) => {
                const active = currentPageName === item.path;
                return (
                  <Link
                    key={item.path}
                    to={createPageUrl(item.path)}
                    className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-all ${
                      active
                        ? "bg-[#172033] text-white shadow-[0_10px_24px_rgba(23,32,51,0.22)]"
                        : "text-[#5d6678] hover:bg-[#edf4fb] hover:text-[#172033]"
                    }`}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            <div className="flex items-center gap-3">
              {user && (
                <div className="flex items-center gap-3 rounded-full border border-white/70 bg-white/80 px-3 py-2 shadow-[0_10px_30px_rgba(26,41,66,0.08)] backdrop-blur-xl">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#0f5bbf] to-[#172033] text-xs font-bold text-white">
                    {(user.full_name || user.email || "U")[0].toUpperCase()}
                  </div>
                  <div className="hidden sm:block">
                    <div className="text-sm font-semibold text-[#172033]">{user.full_name || user.email}</div>
                    <div className="text-[11px] uppercase tracking-[0.16em] text-[#8b93a3]">{user.role || "Member"}</div>
                  </div>
                  <button
                    onClick={() => base44.auth.logout()}
                    className="flex h-9 w-9 items-center justify-center rounded-full text-[#7a8394] transition-colors hover:bg-[#edf4fb] hover:text-[#172033]"
                    title="Sign out"
                  >
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="relative">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-white/55 to-transparent" />
        {children}
      </main>
    </div>
  );
}
