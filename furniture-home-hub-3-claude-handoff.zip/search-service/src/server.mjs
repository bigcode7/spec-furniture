import http from "node:http";
import { readCatalog, readRuns, readVerifiedCatalog } from "./lib/store.mjs";
import { searchCatalog } from "./lib/rank.mjs";
import { getCatalogSummary, ingestVendors, seedSampleCatalog } from "./lib/ingest.mjs";
import { priorityVendors } from "./config/vendors.mjs";
import { discoverLiveVendorProducts } from "./lib/discover.mjs";
import { sampleCatalog } from "./data/sample-catalog.mjs";
import { buildQueryVariants, buildSearchIntent } from "./lib/query-intelligence.mjs";

const host = process.env.SEARCH_SERVICE_HOST || "127.0.0.1";
const port = Number(process.env.SEARCH_SERVICE_PORT || 4310);
const liveWarmVendorIds = ["hooker", "bernhardt", "fourhands"];

function json(res, status, payload) {
  res.writeHead(status, {
    "content-type": "application/json",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type",
  });
  res.end(JSON.stringify(payload, null, 2));
}

function notFound(res) {
  json(res, 404, { error: "Not found" });
}

function collectBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
    });
    req.on("end", () => {
      if (!raw) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(raw));
      } catch (error) {
        reject(error);
      }
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET,POST,OPTIONS",
        "access-control-allow-headers": "content-type",
      });
      res.end();
      return;
    }

    if (req.method === "GET" && req.url === "/health") {
      return json(res, 200, { ok: true });
    }

    if (req.method === "GET" && req.url === "/vendors") {
      return json(res, 200, { vendors: priorityVendors });
    }

    if (req.method === "GET" && req.url === "/catalog") {
      return json(res, 200, {
        summary: getCatalogSummary(),
        catalog: readCatalog(),
        verified_catalog: readVerifiedCatalog(),
      });
    }

    if (req.method === "GET" && req.url === "/runs") {
      return json(res, 200, readRuns());
    }

    if (req.method === "POST" && req.url === "/seed") {
      const payload = await seedSampleCatalog();
      return json(res, 200, {
        ok: true,
        count: payload.products.length,
        updated_at: payload.updated_at,
        vendor_results: payload.vendor_results,
      });
    }

    if (req.method === "POST" && req.url === "/ingest") {
      const body = await collectBody(req);
      const payload = await ingestVendors({
        mode: String(body.mode || "seed"),
        vendorIds: Array.isArray(body.vendor_ids) ? body.vendor_ids.map(String) : [],
      });
      return json(res, 200, {
        ok: true,
        count: payload.products.length,
        updated_at: payload.updated_at,
        vendor_results: payload.vendor_results,
      });
    }

    if (req.method === "POST" && req.url === "/search") {
      const body = await collectBody(req);
      const query = String(body.query || "").trim();
      if (!query) return json(res, 400, { error: "query required" });
      const intent = buildSearchIntent(query);
      const queryVariants = buildQueryVariants(query, intent);
      const searchMode = getSearchMode(body);

      let catalog = readCatalog();
      let verifiedCatalog = readVerifiedCatalog();
      let searchableProducts = filterSearchableProducts(catalog.products, body);
      let verifiedProducts = filterSearchableProducts(verifiedCatalog.products, body);
      let discoveredProducts = [];

      if (searchMode !== "catalog-only" && verifiedProducts.length < 3 && shouldRefreshVerifiedCatalog(verifiedCatalog)) {
        await withTimeout(
          ingestVendors({
            mode: "live",
            vendorIds: liveWarmVendorIds,
          }),
          Number(body.ingest_timeout_ms || 2200),
          null,
        );
        catalog = readCatalog();
        verifiedCatalog = readVerifiedCatalog();
        searchableProducts = filterSearchableProducts(catalog.products, body);
        verifiedProducts = filterSearchableProducts(verifiedCatalog.products, body);
      }

      if (searchMode !== "catalog-only" && verifiedProducts.length < 18) {
        discoveredProducts = await withTimeout(
          discoverAcrossVariants(queryVariants, {
            vendorIds: getSearchVendorIds(body),
            maxVendors: Number(body.max_vendors || 4),
            perVendor: Number(body.per_vendor || 1),
            intent,
          }),
          Number(body.discovery_timeout_ms || 3500),
          [],
        );
      }

      const liveProducts = dedupeProducts([...verifiedProducts, ...searchableProducts, ...discoveredProducts]);
      const liveResults = searchCatalog(liveProducts, queryVariants, body.filters || {}, intent).filter(
        (item) => item.ingestion_source !== "seed",
      );
      const verifiedResults = liveResults.filter((item) => item.image_verified && item.product_url_verified);
      const fallbackSource = catalog.products.length > 0 ? catalog.products : sampleCatalog;
      const directionalResults = searchCatalog(fallbackSource, queryVariants, body.filters || {}, intent).map((item) => ({
        ...item,
        fallback_reason: "live_vendor_results_unavailable",
      }));
      const fallbackResults = searchMode === "verified-only"
        ? []
        : verifiedResults.length > 0
          ? []
          : directionalResults;
      const selectedResults = verifiedResults.length > 0
        ? verifiedResults
        : fallbackResults;
      const responseProducts = selectedResults.map(sanitizeSearchProduct);
      const resultMode = verifiedResults.length > 0
        ? "verified-vendor-results"
        : fallbackResults.length > 0
          ? "directional-catalog-fallback"
          : "no-verified-results";

      return json(res, 200, {
        query,
        intent,
        total: responseProducts.length,
        result_mode: resultMode,
        diagnostics: {
          catalog_count: searchableProducts.length,
          verified_catalog_count: verifiedProducts.length,
          discovered_count: discoveredProducts.length,
          merged_count: liveProducts.length,
          vendor_count: new Set(responseProducts.map((item) => item.vendor_name)).size,
          manufacturer_count: new Set(responseProducts.map((item) => item.vendor_name)).size,
          strict_live_only: !body.allow_seed_results,
          fallback_to_catalog: verifiedResults.length === 0,
          live_result_count: liveResults.length,
          verified_result_count: verifiedResults.length,
          verified_image_count: responseProducts.filter((item) => item.image_verified).length,
          verified_link_count: responseProducts.filter((item) => item.product_url_verified).length,
          result_mode: resultMode,
          search_mode: searchMode,
          query_variants: queryVariants,
        },
        products: responseProducts,
      });
    }

    return notFound(res);
  } catch (error) {
    return json(res, 500, { error: error instanceof Error ? error.message : String(error) });
  }
});

server.listen(port, host, () => {
  console.log(`search-service listening on http://${host}:${port}`);
  queueLiveWarmup();
});

function queueLiveWarmup() {
  setTimeout(async () => {
    try {
      await ingestVendors({
        mode: "live",
        vendorIds: liveWarmVendorIds,
      });
      console.log(`search-service live warmup completed for ${liveWarmVendorIds.join(", ")}`);
    } catch (error) {
      console.error("search-service live warmup failed:", error instanceof Error ? error.message : String(error));
    }
  }, 250);
}

function filterSearchableProducts(products, body) {
  if (body.allow_seed_results) return products;
  return products.filter((product) => product.ingestion_source === "live-crawler" || product.ingestion_source === "live-discovery");
}

function getSearchMode(body) {
  const mode = String(body.search_mode || "").toLowerCase();
  if (["verified-only", "balanced", "catalog-only"].includes(mode)) {
    return mode;
  }
  return "balanced";
}

function shouldRefreshVerifiedCatalog(verifiedCatalog) {
  const updatedAt = verifiedCatalog?.updated_at ? Date.parse(verifiedCatalog.updated_at) : NaN;
  if (!Number.isFinite(updatedAt)) return true;
  return Date.now() - updatedAt > 1000 * 60 * 30;
}

function dedupeProducts(products) {
  const seen = new Map();
  for (const product of products) {
    const key = [product.vendor_id, product.product_url || product.product_name].join("::").toLowerCase();
    if (!seen.has(key)) {
      seen.set(key, product);
    }
  }
  return Array.from(seen.values());
}

function getSearchVendorIds(body) {
  if (Array.isArray(body.vendor_ids) && body.vendor_ids.length > 0) {
    return body.vendor_ids.map(String);
  }
  return priorityVendors.map((vendor) => vendor.id);
}

async function discoverAcrossVariants(queryVariants, options) {
  const results = [];
  for (const variant of queryVariants.slice(0, 4)) {
    const discovered = await discoverLiveVendorProducts(variant, options);
    results.push(...discovered);
  }
  return dedupeProducts(results);
}

async function withTimeout(promise, timeoutMs, fallbackValue) {
  let timeoutId;
  try {
    return await Promise.race([
      promise,
      new Promise((resolve) => {
        timeoutId = setTimeout(() => resolve(fallbackValue), timeoutMs);
      }),
    ]);
  } finally {
    clearTimeout(timeoutId);
  }
}

function sanitizeSearchProduct(product) {
  return {
    ...product,
    retail_price: product.price_verified ? product.retail_price : null,
    wholesale_price: product.price_verified ? product.wholesale_price : null,
    image_url: product.image_verified ? product.image_url : null,
    product_url: product.product_url_verified ? product.product_url : null,
    retrieval_quality_score: Number(product.retrieval_quality_score || 0),
  };
}
