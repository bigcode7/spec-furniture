# SPEC Search Handoff

## Goal

Build SPEC into an AI-native furniture sourcing platform.

Immediate priority:
- search must handle broad furniture briefs, not just exact product phrases
- search must prefer real vendor product pages
- show vendor-hosted images only when verified
- show direct vendor product links only when verified
- never show pricing unless verified
- UI should feel premium and trustworthy

## Current local app

- Frontend: `http://127.0.0.1:4174`
- Search service: `http://127.0.0.1:4310`

## Main search architecture

Frontend:
- [src/pages/Search.jsx](/Users/tylerhoff/Downloads/furniture-home-hub-3/src/pages/Search.jsx)
- [src/api/searchClient.js](/Users/tylerhoff/Downloads/furniture-home-hub-3/src/api/searchClient.js)
- [src/lib/ai-assist.js](/Users/tylerhoff/Downloads/furniture-home-hub-3/src/lib/ai-assist.js)

Standalone search service:
- [search-service/src/server.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/server.mjs)
- [search-service/src/lib/query-intelligence.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/lib/query-intelligence.mjs)
- [search-service/src/lib/rank.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/lib/rank.mjs)
- [search-service/src/lib/discover.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/lib/discover.mjs)
- [search-service/src/lib/vendor-product.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/lib/vendor-product.mjs)
- [search-service/src/adapters/helpers.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/adapters/helpers.mjs)
- [search-service/src/adapters/index.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/adapters/index.mjs)
- [search-service/src/config/vendors.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/config/vendors.mjs)
- [search-service/src/lib/ingest.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/lib/ingest.mjs)
- [search-service/src/lib/store.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/lib/store.mjs)
- [search-service/src/data/sample-catalog.mjs](/Users/tylerhoff/Downloads/furniture-home-hub-3/search-service/src/data/sample-catalog.mjs)

## Current behavior

- Search parses a designer brief into intent.
- Search expands one brief into multiple query variants.
- Search fans discovery across vendors and variants.
- Search stores a normal catalog and a verified catalog.
- Search only exposes `image_url` and `product_url` when verified.
- Search only exposes pricing when verified.
- Frontend separates:
  - verified vendor results
  - directional fallback results

## Current limitation

The trust model is much better than before, but real verified vendor results are still thin.

That means:
- search works
- broad furniture queries work better than before
- UI is stronger
- fake images/links/prices are suppressed
- but exact live vendor results still need better vendor-specific adapters

## Best next backend work

Focus only on top vendors first:
- Hooker
- Bernhardt
- Four Hands

For each one:
- build vendor-specific listing page extraction
- extract exact product-card links from listing/search/category pages
- extract canonical PDP URL
- extract hero image from vendor-hosted assets
- extract title, SKU, collection, category, material, style
- persist verified products into verified catalog

## Best next frontend work

- make search result cards feel more editorial/premium
- improve directional fallback messaging
- show stronger verified-result treatment
- add filters for product type / material / style once backend normalization improves

## Important rules

- Do not show price unless verified.
- Do not show image unless vendor-hosted and verified.
- Do not show product link unless canonical vendor URL is verified.
- Prefer honest directional fallback over fake certainty.

## Commands

Install / lint / build:

```bash
npm run lint
npm run build
```

Run frontend:

```bash
VITE_SEARCH_SERVICE_URL=http://127.0.0.1:4310 npm run dev -- --host 127.0.0.1 --port 4174
```

Run search service:

```bash
npm run search:service
```

Test search API:

```bash
curl -s --max-time 12 -X POST http://127.0.0.1:4310/search \
  -H 'content-type: application/json' \
  -d '{"query":"swivel chairs"}'
```

## What to tell Claude

Use the standalone search service, not just the old Base44 function path.

Primary task:
- improve live vendor adapters and verified product extraction so broad furniture queries return real vendor-hosted images and direct product links

Secondary task:
- continue upgrading the search UI so it looks like a premium AI sourcing platform
